import argparse
from .fetch_papers import fetch_pubmed_pmids, fetch_paper_details
from .process_papers import extract_company_authors, save_to_csv

def main():
    """Command-line interface for PubMed paper fetcher."""
    
    # Setup argument parser
    parser = argparse.ArgumentParser(description="Fetch and filter PubMed research papers with non-academic authors.")
    parser.add_argument("-q", "--query", type=str, required=True, help="Search query for PubMed.")
    parser.add_argument("-f", "--file", type=str, default="filtered_papers.csv", help="Filename to save results (default: filtered_papers.csv).")
    args = parser.parse_args()
    
    # Fetch PMIDs based on user query
    print(f"\n🔍 Searching PubMed for: {args.query}")
    pmid_list = fetch_pubmed_pmids(args.query, retmax=2)  # Fetch 2 PMIDs as per requirement

    if not pmid_list:
        print("❌ No PMIDs found. Exiting.")
        return

    print("\nFound PMIDs:")
    for pmid in pmid_list:
        print(f"- PMID: {pmid} | Link: https://pubmed.ncbi.nlm.nih.gov/{pmid}/")

    # Fetch full paper details
    paper_details = fetch_paper_details(pmid_list)

    # Filter for non-academic authors
    print("\nFiltering Non-Academic Authors...")
    filtered_papers = extract_company_authors(paper_details)

    # Save results to CSV with user-specified filename
    if filtered_papers:
        print(f"\nTotal Papers with Company Authors: {len(filtered_papers)}")
        for paper in filtered_papers:
            print("-" * 50)
            print(f"Title: {paper['Title']}")
            print(f"Publication Date: {paper['Publication Date']}")
            print(f"Company Authors: {paper['Non-academic Authors']}")
        print("-" * 50)
    else:
        print("\nNo papers found with company authors.")

    save_to_csv(filtered_papers, args.file)
    print(f"\n✅ Results saved to {args.file}")

if __name__ == "__main__":
    main()