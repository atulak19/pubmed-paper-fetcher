# PubMed Paper Fetcher

A command-line tool to fetch and filter research papers from PubMed based on author affiliations.

## Installation

```bash
pip install poetry
poetry install
```

## Usage

```bash
poetry run get-papers-list -q "your search query" -f "output.csv"
```

### Options

- `-q, --query`: Search query for PubMed (required)
- `-f, --file`: Output CSV filename (default: filtered_papers.csv)